
import { PricingPlan, Trainer } from './types';

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'basic',
    name: 'Basic',
    price: '₹2000',
    period: 'per month',
    features: ['Unlimited 24/7 Access', 'All Equipment Access', 'Standard Locker Room', 'Professional Training Plans', 'No Time Limitations'],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '₹4800',
    period: 'for 3 months',
    features: ['Unlimited 24/7 Access', 'All Equipment Access', 'Premium Locker Room', 'Professional Training Plans', 'Free Steam & Sauna Access', 'No Time Limitations'],
    recommended: true,
  },
  {
    id: 'elite',
    name: 'Elite',
    price: '₹7500',
    period: 'for 6 months',
    features: ['Unlimited 24/7 Access', 'All Equipment Access', 'VIP Locker Access', 'Professional Training Plans', 'Free Steam & Sauna Access', 'Nutrition & Diet Consulting', 'No Time Limitations'],
  }
];

export const TRAINERS: Trainer[] = [
  {
    id: '1',
    name: 'Alex Rivera',
    specialty: 'Strength & Conditioning',
    image: 'https://picsum.photos/id/64/400/400',
    bio: 'With over 10 years of experience in competitive bodybuilding, Alex focuses on high-intensity muscle building and structural integrity.',
    contact: '+91 98765 43210'
  },
  {
    id: '2',
    name: 'Sarah Jenkins',
    specialty: 'Functional Fitness',
    image: 'https://picsum.photos/id/65/400/400',
    bio: 'Certified specialist in mobility and functional movement. Sarah helps members achieve real-world strength and athletic agility.',
    contact: '+91 98765 43211'
  },
  {
    id: '3',
    name: 'Mike Thompson',
    specialty: 'Weight Management',
    image: 'https://picsum.photos/id/66/400/400',
    bio: 'Mike specializes in transformative cardio programs and sustainable weight loss through science-based endurance training.',
    contact: '+91 98765 43212'
  }
];

// Programs are removed as per request
export const PROGRAMS = [];
