import React, { useState } from 'react';
import { fitnessCoach } from '../services/gemini';

const GeminiFitnessCoach: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [goal, setGoal] = useState('');
  const [level, setLevel] = useState('Beginner');
  const [advice, setAdvice] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGetAdvice = async () => {
    if (!goal) return;
    setLoading(true);
    setAdvice('');
    const result = await fitnessCoach.getFitnessAdvice(goal, level);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <>
      {/* Floating Toggle Button */}
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-emerald-600 text-white rounded-full shadow-2xl hover:bg-emerald-700 flex items-center justify-center z-40 transition-transform hover:scale-110 active:scale-95 shadow-emerald-600/20"
        title="Ask AI Fitness Coach"
      >
        <i className="fa-solid fa-robot text-2xl"></i>
      </button>

      {/* Modal / Sidebar */}
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-lg rounded-lg overflow-hidden flex flex-col shadow-2xl">
            <div className="p-6 bg-zinc-950 border-b border-zinc-800 flex justify-between items-center">
              <h3 className="text-xl oswald text-emerald-500 tracking-wider">AI Fitness Assistant</h3>
              <button onClick={() => setIsOpen(false)} className="text-zinc-400 hover:text-white"><i className="fa-solid fa-xmark text-xl"></i></button>
            </div>
            
            <div className="p-6 space-y-4 overflow-y-auto max-h-[70vh]">
              {!advice ? (
                <>
                  <p className="text-zinc-300 text-sm">Tell me your goals, and I'll generate a personalized starting plan for you using Gemini AI.</p>
                  <div>
                    <label className="block text-xs uppercase font-bold text-zinc-500 mb-1 tracking-widest">Fitness Goal</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Lose 10lbs, Bench press 225lbs, Improve cardio"
                      className="w-full bg-zinc-800 border border-zinc-700 rounded p-3 text-white focus:ring-1 focus:ring-emerald-600 outline-none"
                      value={goal}
                      onChange={(e) => setGoal(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase font-bold text-zinc-500 mb-1 tracking-widest">Experience Level</label>
                    <select 
                      className="w-full bg-zinc-800 border border-zinc-700 rounded p-3 text-white focus:ring-1 focus:ring-emerald-600 outline-none"
                      value={level}
                      onChange={(e) => setLevel(e.target.value)}
                    >
                      <option>Beginner</option>
                      <option>Intermediate</option>
                      <option>Advanced</option>
                    </select>
                  </div>
                  <button 
                    disabled={loading || !goal}
                    onClick={handleGetAdvice}
                    className="w-full bg-emerald-600 text-white font-bold py-3 rounded hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed tracking-widest"
                  >
                    {loading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : "GENERATE PLAN"}
                  </button>
                </>
              ) : (
                <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-300">
                  <div className="bg-zinc-800 p-4 rounded-lg text-zinc-200 border-l-4 border-emerald-500 whitespace-pre-line leading-relaxed italic">
                    {advice}
                  </div>
                  <button 
                    onClick={() => setAdvice('')}
                    className="w-full bg-zinc-800 text-zinc-300 font-bold py-3 rounded hover:bg-zinc-700 transition-colors"
                  >
                    ASK AGAIN
                  </button>
                </div>
              )}
            </div>
            
            <div className="p-4 bg-zinc-950 border-t border-zinc-800 text-[10px] text-center text-zinc-600">
              Powered by Google Gemini 3 Flash • Good Job Fitness Gym Coaching AI
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GeminiFitnessCoach;