
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full z-50 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center space-x-2">
              <span className="text-emerald-500 text-3xl font-extrabold oswald italic tracking-tighter">GOOD JOB</span>
              <span className="text-white text-3xl font-light oswald tracking-widest">FITNESS</span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-6">
              <Link to="/" className="text-zinc-300 hover:text-emerald-400 px-3 py-2 text-xs font-semibold uppercase tracking-widest transition-colors">Home</Link>
              <Link to="/gallery" className="text-zinc-300 hover:text-emerald-400 px-3 py-2 text-xs font-semibold uppercase tracking-widest transition-colors">Ambience</Link>
              <Link to="/pricing" className="text-zinc-300 hover:text-emerald-400 px-3 py-2 text-xs font-semibold uppercase tracking-widest transition-colors">Pricing</Link>
              <Link to="/trainers" className="text-zinc-300 hover:text-emerald-400 px-3 py-2 text-xs font-semibold uppercase tracking-widest transition-colors">Trainers</Link>
              <Link to="/contact" className="text-zinc-300 hover:text-emerald-400 px-3 py-2 text-xs font-semibold uppercase tracking-widest transition-colors">Contact</Link>
            </div>
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 focus:outline-none"
            >
              <i className={`fa-solid ${isOpen ? 'fa-xmark' : 'fa-bars'} text-2xl`}></i>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-zinc-900 border-b border-zinc-800 animate-in fade-in slide-in-from-top duration-300">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" onClick={() => setIsOpen(false)} className="block text-zinc-300 hover:text-emerald-400 px-3 py-4 text-base font-bold uppercase">Home</Link>
            <Link to="/gallery" onClick={() => setIsOpen(false)} className="block text-zinc-300 hover:text-emerald-400 px-3 py-4 text-base font-bold uppercase">Gallery</Link>
            <Link to="/pricing" onClick={() => setIsOpen(false)} className="block text-zinc-300 hover:text-emerald-400 px-3 py-4 text-base font-bold uppercase">Pricing</Link>
            <Link to="/trainers" onClick={() => setIsOpen(false)} className="block text-zinc-300 hover:text-emerald-400 px-3 py-4 text-base font-bold uppercase">Trainers</Link>
            <Link to="/contact" onClick={() => setIsOpen(false)} className="block text-zinc-300 hover:text-emerald-400 px-3 py-4 text-base font-bold uppercase">Contact</Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
