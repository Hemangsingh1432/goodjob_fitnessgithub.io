
import React from 'react';
import { Link } from 'react-router-dom';
import { useContent } from '../context/ContentContext';

const Footer: React.FC = () => {
  const { content } = useContent();

  return (
    <footer className="bg-zinc-950 border-t border-zinc-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-emerald-500 text-3xl font-extrabold oswald italic tracking-tighter">GOOD JOB</span>
              <span className="text-white text-3xl font-light oswald tracking-widest">FITNESS</span>
            </Link>
            <p className="text-zinc-400 text-sm leading-relaxed">
              Good Job Fitness Gym is a premier destination for athletes and fitness enthusiasts. We provide the tools, the community, and the coaching to help you transform your body and mind.
            </p>
          </div>

          <div>
            <h3 className="text-white font-bold uppercase tracking-widest mb-6">Quick Links</h3>
            <ul className="space-y-4 text-zinc-400 text-sm">
              <li><Link to="/" className="hover:text-emerald-500 transition-colors">Home</Link></li>
              <li><Link to="/pricing" className="hover:text-emerald-500 transition-colors">Pricing</Link></li>
              <li><Link to="/trainers" className="hover:text-emerald-500 transition-colors">Our Trainers</Link></li>
              <li><Link to="/contact" className="hover:text-emerald-500 transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold uppercase tracking-widest mb-6">Connect</h3>
            <div className="flex space-x-4">
              <a 
                href={content.social.instagram} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-white hover:bg-emerald-600 transition-colors"
                aria-label="Instagram"
              >
                <i className="fa-brands fa-instagram"></i>
              </a>
              <a 
                href={content.social.facebook} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-white hover:bg-emerald-600 transition-colors"
                aria-label="Facebook"
              >
                <i className="fa-brands fa-facebook-f"></i>
              </a>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-white font-bold uppercase tracking-widest mb-6">Staff Access</h3>
              <div className="space-y-4">
                <Link to="/admin" className="text-zinc-600 hover:text-emerald-500 text-xs uppercase tracking-widest font-bold flex items-center transition-colors">
                  <i className="fa-solid fa-lock mr-2"></i> Owner Dashboard
                </Link>
                <Link to="/attendance" className="text-zinc-600 hover:text-emerald-500 text-xs uppercase tracking-widest font-bold flex items-center transition-colors">
                  <i className="fa-solid fa-id-card-clip mr-2"></i> Attendance Portal
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center text-zinc-500 text-xs">
          <p>© 2024 Good Job Fitness Gym. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
