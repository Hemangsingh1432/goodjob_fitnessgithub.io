
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import PricingPage from './pages/PricingPage';
import TrainersPage from './pages/TrainersPage';
import ContactPage from './pages/ContactPage';
import GalleryPage from './pages/GalleryPage';
import Admin from './pages/Admin';
import AttendancePortal from './pages/AttendancePortal';
import GeminiFitnessCoach from './components/GeminiFitnessCoach';
import { ContentProvider } from './context/ContentContext';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <ContentProvider>
      <Router>
        <ScrollToTop />
        <div className="flex flex-col min-h-screen selection:bg-emerald-600 selection:text-white">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/gallery" element={<GalleryPage />} />
              <Route path="/pricing" element={<PricingPage />} />
              <Route path="/trainers" element={<TrainersPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/attendance" element={<AttendancePortal />} />
            </Routes>
          </main>
          <Footer />
          <GeminiFitnessCoach />
        </div>
      </Router>
    </ContentProvider>
  );
};

export default App;
