
import React from 'react';
import { useContent } from '../context/ContentContext';

const PricingPage: React.FC = () => {
  const { content } = useContent();

  return (
    <div className="bg-zinc-950 min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h1 className="text-emerald-500 font-bold uppercase tracking-[0.3em] mb-4 text-sm">Membership Investment</h1>
          <h2 className="text-white text-5xl md:text-7xl font-black uppercase oswald italic mb-8 tracking-tighter">Clear & <span className="text-emerald-500">Transparent</span></h2>
          <p className="text-zinc-400 max-w-2xl mx-auto text-lg font-light italic">No hidden fees. Full access for all members regardless of plan duration.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {content.pricing.map((plan) => (
            <div 
              key={plan.id} 
              className={`relative bg-zinc-900/50 border ${plan.recommended ? 'border-emerald-500 shadow-2xl shadow-emerald-900/20' : 'border-zinc-800'} p-10 flex flex-col rounded-sm`}
            >
              {plan.recommended && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-emerald-500 text-white text-[10px] font-black uppercase tracking-widest px-6 py-2 rounded-full shadow-lg shadow-emerald-200">
                  Most Popular
                </div>
              )}
              <div className="mb-10 text-center">
                <h3 className="text-zinc-400 text-xs font-bold uppercase tracking-[0.2em] mb-4">{plan.name} Strategy</h3>
                <div className="flex flex-col items-center text-white">
                  <span className="text-6xl font-black oswald tracking-tighter mb-2">{plan.price}</span>
                  <span className="text-zinc-500 font-light italic text-sm">{plan.period}</span>
                </div>
              </div>
              <div className="h-px bg-zinc-800 w-full mb-10"></div>
              <ul className="space-y-5 mb-12 flex-grow">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start space-x-3 text-zinc-300 text-sm">
                    <div className="mt-1 w-4 h-4 bg-emerald-500/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="fa-solid fa-check text-emerald-500 text-[8px]"></i>
                    </div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <div className="text-center py-4 bg-zinc-950 border border-zinc-800 text-zinc-400 text-[10px] font-bold uppercase tracking-widest">
                Professional Plan
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 py-16 px-10 bg-zinc-900/50 border border-zinc-800 rounded-sm text-center">
          <h3 className="text-white text-3xl font-bold uppercase oswald mb-4 italic">No Limitations Policy</h3>
          <p className="text-zinc-400 max-w-2xl mx-auto font-light leading-relaxed">
            Unlike other facilities, we do not restrict access based on your price point. Every single plan includes 24/7 unlimited access to all machines, free weights, and functional training areas. Your investment covers everything we offer.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PricingPage;
