
import React from 'react';
import { useContent } from '../context/ContentContext';

const GalleryPage: React.FC = () => {
  const { content } = useContent();

  return (
    <div className="bg-zinc-950 min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-emerald-500 font-bold uppercase tracking-[0.4em] mb-4 text-xs">Visual Ambience</h1>
          <h2 className="text-white text-5xl md:text-7xl font-black uppercase oswald italic mb-6 tracking-tighter">The <span className="text-emerald-500">Facility</span></h2>
          <p className="text-zinc-500 max-w-xl mx-auto text-sm uppercase tracking-widest font-bold opacity-80">Take a virtual tour of our high-performance training ground.</p>
          <div className="h-1 w-20 bg-emerald-500 mx-auto mt-8"></div>
        </div>

        {(!content.gallery || content.gallery.length === 0) ? (
          <div className="py-20 text-center border border-zinc-900 bg-zinc-900/20 rounded-sm">
            <i className="fa-solid fa-camera-retro text-zinc-800 text-6xl mb-4"></i>
            <p className="text-zinc-600 font-bold uppercase tracking-widest">No gallery photos have been added by the owner yet.</p>
          </div>
        ) : (
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
            {content.gallery.map((img) => (
              <div 
                key={img.id} 
                className="relative group overflow-hidden bg-zinc-900 rounded-sm break-inside-avoid"
              >
                <img 
                  src={img.url} 
                  alt="Gym Ambience" 
                  className="w-full h-auto object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105" 
                />
                <div className="absolute inset-0 bg-emerald-950/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                  <p className="text-white text-[10px] font-black uppercase tracking-widest italic">Good Job Fitness Ambience</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default GalleryPage;
