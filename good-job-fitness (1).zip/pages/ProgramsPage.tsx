import React from 'react';
import { PROGRAMS } from '../constants';

const ProgramsPage: React.FC = () => {
  return (
    <div className="bg-zinc-950 min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h1 className="text-emerald-500 font-bold uppercase tracking-[0.3em] mb-4 text-sm">Training Programs</h1>
          <h2 className="text-white text-5xl md:text-7xl font-black uppercase oswald italic mb-8">What Is Your <span className="text-emerald-500">Objective?</span></h2>
          <p className="text-zinc-400 max-w-2xl mx-auto text-lg font-light italic">We offer specialized training paths for every fitness level and ambition.</p>
        </div>

        <div className="space-y-16">
          {PROGRAMS.map((prog, idx) => (
            <div 
              key={prog.id} 
              className={`flex flex-col lg:flex-row bg-zinc-900 border border-zinc-800 overflow-hidden rounded-sm hover:border-emerald-500 transition-colors duration-500 ${idx % 2 === 0 ? '' : 'lg:flex-row-reverse'}`}
            >
              <div className="lg:w-2/5 relative">
                <img src={prog.image} alt={prog.title} className="w-full h-full object-cover min-h-[400px] grayscale group-hover:grayscale-0 transition-all duration-700" />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-transparent transition-all duration-500"></div>
              </div>
              <div className="lg:w-3/5 p-12 lg:p-16 flex flex-col justify-center">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-16 h-16 bg-zinc-800 flex items-center justify-center text-emerald-500 text-3xl border border-zinc-700 rounded-sm">
                    <i className={`fa-solid ${prog.icon}`}></i>
                  </div>
                  <h3 className="text-white text-3xl font-black uppercase oswald italic tracking-wide">{prog.title}</h3>
                </div>
                <p className="text-zinc-400 text-lg leading-relaxed mb-8 font-light italic">
                  {prog.description} Full session analysis, biometric tracking, and adaptive scheduling included in all memberships for this track.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
                  <div className="bg-zinc-950 p-4 border border-zinc-800">
                    <p className="text-emerald-500 text-xs font-black uppercase tracking-widest mb-1">Intensity</p>
                    <p className="text-white font-bold text-sm tracking-wider">HIGH</p>
                  </div>
                  <div className="bg-zinc-950 p-4 border border-zinc-800">
                    <p className="text-emerald-500 text-xs font-black uppercase tracking-widest mb-1">Duration</p>
                    <p className="text-white font-bold text-sm tracking-wider">45-60M</p>
                  </div>
                </div>
                <button className="self-start bg-emerald-600 text-white font-black uppercase tracking-widest px-10 py-5 hover:bg-white hover:text-black transition-all rounded-sm shadow-lg shadow-emerald-600/10">Enroll In Program</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProgramsPage;