
import React, { useState, useRef, useEffect } from 'react';
import { useContent } from '../context/ContentContext';
import { SiteContent, Trainer, PricingPlan, Inquiry, GalleryImage, Review, ScheduleEntry, Advantage } from '../types';

const Admin: React.FC = () => {
  const { content, updateContent, resetToDefault } = useContent();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'general' | 'advantages' | 'pricing' | 'trainers' | 'gallery' | 'contact' | 'inquiries' | 'reviews' | 'schedule'>('general');
  
  // Drafting System
  const [draftContent, setDraftContent] = useState<SiteContent>(content);
  const [hasChanges, setHasChanges] = useState(false);
  const [showSaveConfirmModal, setShowSaveConfirmModal] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync draft with content when login happens or global content is updated externally
  useEffect(() => {
    setDraftContent(content);
    setHasChanges(false);
  }, [content, isLoggedIn]);

  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  
  // Custom Modal States
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showAddTrainerModal, setShowAddTrainerModal] = useState(false);
  const [showAddReviewModal, setShowAddReviewModal] = useState(false);
  
  // Deletion Tracking
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [pendingEntityType, setPendingEntityType] = useState<'gallery' | 'trainer' | 'pricing' | 'inquiry' | 'review'>('gallery');
  const [pendingAction, setPendingAction] = useState<'single' | 'bulk' | 'all'>('single');
  
  // New Trainer Form State
  const [newTrainer, setNewTrainer] = useState<Omit<Trainer, 'id'>>({
    name: '',
    specialty: '',
    bio: '',
    contact: '',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=400&fit=crop'
  });

  // New Review Form State
  const [newReview, setNewReview] = useState<Omit<Review, 'id' | 'date'>>({
    name: '',
    rating: 5,
    comment: ''
  });

  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const trainerInputRef = useRef<HTMLInputElement>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123' || password === '1978') { 
      setIsLoggedIn(true);
    } else {
      alert('Incorrect Password');
    }
  };

  const markChanged = () => setHasChanges(true);

  const discardDraft = () => {
    if (window.confirm("Discard all unsaved changes in this session?")) {
      setDraftContent(content);
      setHasChanges(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, target: 'hero' | 'about' | 'gallery' | 'new-trainer' | string) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    markChanged();

    const fileList = Array.from(files) as File[];
    fileList.forEach(file => {
      if (file.size > 2 * 1024 * 1024) {
        alert(`${file.name} is too large (>2MB).`);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        if (target === 'new-trainer') {
          setNewTrainer(prev => ({ ...prev, image: base64String }));
          return;
        }

        setDraftContent(prev => {
          if (target === 'hero') {
            return { ...prev, hero: { ...prev.hero, backgroundImage: base64String } };
          } else if (target === 'about') {
            return { ...prev, about: { ...prev.about, image: base64String } };
          } else if (target === 'gallery') {
            const newImg: GalleryImage = {
              id: 'img_' + Math.random().toString(36).substr(2, 9),
              url: base64String
            };
            return { ...prev, gallery: [...(prev.gallery || []), newImg] };
          } else {
            const newTrainers = prev.trainers.map(t => 
              t.id === target ? { ...t, image: base64String } : t
            );
            return { ...prev, trainers: newTrainers };
          }
        });
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const handleSaveChanges = () => {
    updateContent(draftContent);
    setHasChanges(false);
    setShowSaveConfirmModal(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const triggerDelete = (id: string, type: 'gallery' | 'trainer' | 'pricing' | 'inquiry' | 'review', action: 'single' | 'bulk' | 'all' = 'single') => {
    setPendingDeleteId(id);
    setPendingEntityType(type);
    setPendingAction(action);
    setShowConfirmModal(true);
  };

  const executeDeletion = () => {
    markChanged();
    setDraftContent(prev => {
      let newState = { ...prev };
      if (pendingEntityType === 'gallery') {
        if (pendingAction === 'single') newState.gallery = (prev.gallery || []).filter(img => img.id !== pendingDeleteId);
        else if (pendingAction === 'bulk') newState.gallery = (prev.gallery || []).filter(img => !selectedImages.includes(img.id));
      } else if (pendingEntityType === 'trainer') newState.trainers = prev.trainers.filter(t => t.id !== pendingDeleteId);
      else if (pendingEntityType === 'pricing') newState.pricing = prev.pricing.filter(p => p.id !== pendingDeleteId);
      else if (pendingEntityType === 'inquiry') newState.inquiries = prev.inquiries.filter(i => i.id !== pendingDeleteId);
      else if (pendingEntityType === 'review') newState.reviews = prev.reviews.filter(r => r.id !== pendingDeleteId);
      return newState;
    });
    setShowConfirmModal(false);
  };

  const handleAddTrainer = (e: React.FormEvent) => {
    e.preventDefault();
    markChanged();
    setDraftContent(prev => ({ ...prev, trainers: [...prev.trainers, { ...newTrainer, id: 'trainer_' + Date.now() }] }));
    setShowAddTrainerModal(false);
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    markChanged();
    const review: Review = {
      ...newReview,
      id: 'rev_' + Date.now(),
      date: new Date().toISOString().split('T')[0]
    };
    setDraftContent(prev => ({ ...prev, reviews: [review, ...(prev.reviews || [])] }));
    setShowAddReviewModal(false);
  };

  const updateScheduleEntry = (index: number, field: keyof ScheduleEntry, value: string) => {
    markChanged();
    setDraftContent(prev => {
        const newSchedule = [...prev.schedule];
        newSchedule[index] = { ...newSchedule[index], [field]: value };
        return { ...prev, schedule: newSchedule };
    });
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
        <form onSubmit={handleLogin} className="bg-zinc-900 p-10 border border-zinc-800 rounded-sm w-full max-w-md shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500"></div>
          <h2 className="text-3xl font-black oswald text-white mb-8 italic tracking-tighter uppercase leading-none">OWNER <span className="text-emerald-500">ACCESS</span></h2>
          <div className="space-y-6">
            <div className="relative">
              <i className="fa-solid fa-shield-halved absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600"></i>
              <input 
                type="password" 
                placeholder="Admin Credentials" 
                className="w-full bg-zinc-950 border border-zinc-800 p-4 pl-12 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-700"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
              />
            </div>
            <button className="w-full bg-emerald-600 text-white font-black py-4 hover:bg-emerald-700 transition-all uppercase tracking-widest text-sm shadow-xl shadow-emerald-900/20">Open Dashboard</button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* STICKY ACTION HEADER */}
      <div className="fixed top-20 left-0 w-full z-40 bg-zinc-900/90 backdrop-blur-xl border-b border-zinc-800 h-16 flex items-center shadow-2xl">
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className={`w-2 h-2 rounded-full ${hasChanges ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></div>
            <span className="text-zinc-400 text-[9px] font-black uppercase tracking-[0.2em] hidden sm:block">
              {hasChanges ? 'Pending Modifications' : 'Cloud Sync Active'}
            </span>
          </div>
          <div className="flex items-center space-x-4">
            {hasChanges && (
               <div className="flex items-center space-x-3">
                 <button 
                   onClick={discardDraft}
                   className="text-zinc-500 hover:text-white px-4 py-2 text-[9px] font-black uppercase tracking-widest transition-colors"
                 >
                   Discard
                 </button>
                 <button 
                   onClick={() => setShowSaveConfirmModal(true)}
                   className="bg-emerald-600 text-white px-6 py-2 rounded-sm font-black oswald uppercase italic tracking-widest text-xs hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-900/40 flex items-center group"
                 >
                   <i className="fa-solid fa-floppy-disk mr-2 group-hover:scale-110 transition-transform"></i> 
                   Save All Updates
                 </button>
               </div>
            )}
            <button onClick={() => setIsLoggedIn(false)} className="text-zinc-600 hover:text-white text-[9px] font-black uppercase tracking-widest transition-colors border-l border-zinc-800 pl-4 ml-4">
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="pt-44 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
           <div>
              <h1 className="text-white text-5xl font-black oswald italic uppercase leading-none tracking-tighter">Site <span className="text-emerald-500">Management</span></h1>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-2 italic">Professional Grade Controls</p>
           </div>
           <button onClick={resetToDefault} className="text-red-900 hover:text-red-500 text-[9px] font-black uppercase tracking-widest transition-colors border border-red-900/20 px-3 py-1">Factory Reset</button>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-6 mb-10 border-b border-zinc-900 overflow-x-auto whitespace-nowrap scrollbar-hide pb-1">
          {(['general', 'advantages', 'pricing', 'trainers', 'gallery', 'reviews', 'schedule', 'contact', 'inquiries'] as const).map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-4 px-2 font-black uppercase text-[10px] tracking-widest transition-all relative ${activeTab === tab ? 'text-emerald-500' : 'text-zinc-600 hover:text-zinc-300'}`}
            >
              {tab === 'inquiries' && (draftContent.inquiries?.length || 0) > 0 && (
                <span className="absolute -top-1 -right-2 bg-emerald-600 text-white text-[7px] px-1 rounded-full">{draftContent.inquiries.length}</span>
              )}
              {tab}
              {activeTab === tab && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-emerald-500"></div>}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-zinc-900/40 border border-zinc-800 p-8 rounded-sm shadow-xl min-h-[500px]">
          {activeTab === 'general' && (
            <div className="space-y-12 animate-in fade-in duration-300">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="space-y-6">
                    <h3 className="text-white font-black oswald text-xl uppercase italic border-b border-zinc-800 pb-2">Hero Section</h3>
                    <div className="space-y-4">
                      <label className="block text-zinc-600 text-[10px] uppercase font-black tracking-widest">Main Headline</label>
                      <input 
                        className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-lg font-black oswald italic uppercase focus:border-emerald-500 outline-none" 
                        value={draftContent.hero.title} 
                        onChange={e => { markChanged(); setDraftContent(prev => ({...prev, hero: {...prev.hero, title: e.target.value}})) }}
                      />
                      <label className="block text-zinc-600 text-[10px] uppercase font-black tracking-widest">Description</label>
                      <textarea 
                        className="w-full bg-zinc-950 border border-zinc-800 p-4 text-zinc-400 text-sm h-32 resize-none leading-relaxed italic focus:border-emerald-500 outline-none" 
                        value={draftContent.hero.subtitle}
                        onChange={e => { markChanged(); setDraftContent(prev => ({...prev, hero: {...prev.hero, subtitle: e.target.value}})) }}
                      />
                    </div>
                  </div>
                  <div className="space-y-6">
                    <h3 className="text-white font-black oswald text-xl uppercase italic border-b border-zinc-800 pb-2">Ambience Visual</h3>
                    <div className="aspect-video bg-zinc-950 border border-zinc-800 overflow-hidden relative group">
                      <img src={draftContent.hero.backgroundImage} className="w-full h-full object-cover" alt="Hero" />
                      <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer" onClick={() => fileInputRefs.current['hero']?.click()}>
                        <i className="fa-solid fa-camera text-3xl text-white mb-2"></i>
                        <span className="text-white text-[10px] font-black uppercase tracking-widest">Replace Photo</span>
                      </div>
                    </div>
                    <input type="file" className="hidden" ref={el => { fileInputRefs.current['hero'] = el; }} onChange={e => handleFileChange(e, 'hero')} accept="image/*" />
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'advantages' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
               {draftContent.advantages.map((adv, idx) => (
                 <div key={adv.id} className="bg-zinc-950 border border-zinc-800 p-6 rounded-sm space-y-4">
                   <div className="flex items-center space-x-3 mb-2">
                     <i className={`fa-solid ${adv.icon} text-emerald-500`}></i>
                     <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Feature {idx + 1}</span>
                   </div>
                   <input 
                     className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white text-sm font-bold oswald uppercase"
                     value={adv.title}
                     onChange={e => {
                       markChanged();
                       const newAdvs = [...draftContent.advantages];
                       newAdvs[idx].title = e.target.value;
                       setDraftContent(prev => ({...prev, advantages: newAdvs}));
                     }}
                   />
                   <textarea 
                     className="w-full bg-zinc-900 border border-zinc-800 p-3 text-zinc-400 text-xs h-24 resize-none leading-relaxed italic"
                     value={adv.desc}
                     onChange={e => {
                       markChanged();
                       const newAdvs = [...draftContent.advantages];
                       newAdvs[idx].desc = e.target.value;
                       setDraftContent(prev => ({...prev, advantages: newAdvs}));
                     }}
                   />
                 </div>
               ))}
            </div>
          )}

          {activeTab === 'pricing' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              {draftContent.pricing.map((plan, idx) => (
                <div key={plan.id} className="bg-zinc-950 border border-zinc-800 p-8 rounded-sm grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="space-y-4">
                    <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Plan Identity</label>
                    <input className="w-full bg-zinc-900 border border-zinc-800 p-4 text-white font-bold oswald uppercase" value={plan.name} onChange={e => {
                      markChanged();
                      const np = [...draftContent.pricing];
                      np[idx].name = e.target.value;
                      setDraftContent(prev => ({...prev, pricing: np}));
                    }} />
                    <div className="flex space-x-4">
                      <div className="flex-1">
                        <label className="text-zinc-600 text-[9px] font-black uppercase tracking-widest">Price</label>
                        <input className="w-full bg-zinc-900 border border-zinc-800 p-4 text-emerald-500 font-black oswald text-xl" value={plan.price} onChange={e => {
                          markChanged();
                          const np = [...draftContent.pricing];
                          np[idx].price = e.target.value;
                          setDraftContent(prev => ({...prev, pricing: np}));
                        }} />
                      </div>
                      <div className="flex-1">
                        <label className="text-zinc-600 text-[9px] font-black uppercase tracking-widest">Period</label>
                        <input className="w-full bg-zinc-900 border border-zinc-800 p-4 text-zinc-400 text-xs" value={plan.period} onChange={e => {
                          markChanged();
                          const np = [...draftContent.pricing];
                          np[idx].period = e.target.value;
                          setDraftContent(prev => ({...prev, pricing: np}));
                        }} />
                      </div>
                    </div>
                  </div>
                  <div className="lg:col-span-2 space-y-4">
                    <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Inclusions (One per line)</label>
                    <textarea 
                      className="w-full bg-zinc-900 border border-zinc-800 p-4 text-zinc-300 text-xs h-32 font-mono leading-relaxed" 
                      value={plan.features.join('\n')} 
                      onChange={e => {
                        markChanged();
                        const np = [...draftContent.pricing];
                        np[idx].features = e.target.value.split('\n');
                        setDraftContent(prev => ({...prev, pricing: np}));
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'trainers' && (
            <div className="space-y-8 animate-in fade-in duration-300">
               <div className="flex justify-end">
                 <button onClick={() => setShowAddTrainerModal(true)} className="bg-emerald-600 text-white px-8 py-3 rounded-sm font-black oswald uppercase text-xs hover:bg-emerald-500 transition-all">+ Add Coach</button>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 {draftContent.trainers.map((trainer, idx) => (
                   <div key={trainer.id} className="bg-zinc-950 border border-zinc-800 p-6 rounded-sm flex space-x-6 relative group">
                     <button onClick={() => triggerDelete(trainer.id, 'trainer')} className="absolute top-4 right-4 text-zinc-800 hover:text-red-500 transition-colors">
                       <i className="fa-solid fa-trash-can text-sm"></i>
                     </button>
                     <div className="w-32 h-32 bg-zinc-900 rounded-sm overflow-hidden flex-shrink-0 relative group">
                        <img src={trainer.image} className="w-full h-full object-cover" alt={trainer.name} />
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity" onClick={() => fileInputRefs.current[trainer.id]?.click()}>
                          <i className="fa-solid fa-camera text-white"></i>
                        </div>
                        <input type="file" className="hidden" ref={el => { fileInputRefs.current[trainer.id] = el }} onChange={e => handleFileChange(e, trainer.id)} />
                     </div>
                     <div className="flex-grow space-y-3">
                       <input className="w-full bg-transparent border-b border-zinc-800 text-white font-bold oswald uppercase focus:border-emerald-500 outline-none" value={trainer.name} onChange={e => {
                         markChanged();
                         const nt = [...draftContent.trainers];
                         nt[idx].name = e.target.value;
                         setDraftContent(prev => ({...prev, trainers: nt}));
                       }} />
                       <input className="w-full bg-transparent text-emerald-500 text-[10px] font-black uppercase tracking-widest focus:border-emerald-500 outline-none" value={trainer.specialty} onChange={e => {
                         markChanged();
                         const nt = [...draftContent.trainers];
                         nt[idx].specialty = e.target.value;
                         setDraftContent(prev => ({...prev, trainers: nt}));
                       }} />
                       <textarea className="w-full bg-transparent text-zinc-500 text-xs italic leading-relaxed resize-none focus:text-zinc-300 outline-none" value={trainer.bio} onChange={e => {
                         markChanged();
                         const nt = [...draftContent.trainers];
                         nt[idx].bio = e.target.value;
                         setDraftContent(prev => ({...prev, trainers: nt}));
                       }} rows={2} />
                     </div>
                   </div>
                 ))}
               </div>
            </div>
          )}

          {activeTab === 'gallery' && (
            <div className="animate-in fade-in duration-300">
               <div className="flex justify-between items-center mb-8">
                  <h3 className="text-white text-xl font-black oswald uppercase italic">{draftContent.gallery?.length || 0} Assets</h3>
                  <div className="flex space-x-4">
                    <button onClick={() => setIsSelectionMode(!isSelectionMode)} className={`text-[10px] font-black uppercase tracking-widest px-4 py-2 border ${isSelectionMode ? 'bg-emerald-600 text-white border-emerald-500' : 'text-zinc-500 border-zinc-800 hover:text-white'}`}>
                      {isSelectionMode ? 'Exit Selection' : 'Bulk Delete'}
                    </button>
                    {isSelectionMode && selectedImages.length > 0 && (
                      <button onClick={() => triggerDelete('', 'gallery', 'bulk')} className="bg-red-600 text-white text-[10px] font-black px-4 py-2 uppercase tracking-widest">Remove Selected ({selectedImages.length})</button>
                    )}
                    <button onClick={() => galleryInputRef.current?.click()} className="bg-emerald-600 text-white text-[10px] font-black px-4 py-2 uppercase tracking-widest">+ Upload</button>
                  </div>
               </div>
               <input type="file" multiple accept="image/*" className="hidden" ref={galleryInputRef} onChange={e => handleFileChange(e, 'gallery')} />
               <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                 {draftContent.gallery?.map(img => (
                   <div 
                    key={img.id} 
                    className={`relative aspect-square border transition-all cursor-pointer overflow-hidden group ${isSelectionMode && selectedImages.includes(img.id) ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-zinc-800'}`}
                    onClick={() => {
                      if (isSelectionMode) {
                        setSelectedImages(prev => prev.includes(img.id) ? prev.filter(i => i !== img.id) : [...prev, img.id]);
                      }
                    }}
                   >
                     <img src={img.url} className={`w-full h-full object-cover grayscale transition-all ${isSelectionMode && selectedImages.includes(img.id) ? 'opacity-40 grayscale-0' : 'group-hover:grayscale-0'}`} alt="Gallery" />
                     {!isSelectionMode && (
                        <button onClick={(e) => { e.stopPropagation(); triggerDelete(img.id, 'gallery'); }} className="absolute top-2 right-2 w-8 h-8 bg-red-600 text-white flex items-center justify-center rounded-sm opacity-0 group-hover:opacity-100 transition-opacity">
                          <i className="fa-solid fa-trash-can text-xs"></i>
                        </button>
                     )}
                     {isSelectionMode && selectedImages.includes(img.id) && (
                        <div className="absolute inset-0 flex items-center justify-center bg-emerald-500/10">
                           <i className="fa-solid fa-circle-check text-emerald-500 text-2xl"></i>
                        </div>
                     )}
                   </div>
                 ))}
               </div>
            </div>
          )}

          {activeTab === 'schedule' && (
            <div className="grid grid-cols-1 gap-4 animate-in fade-in duration-300">
               {draftContent.schedule.map((entry, idx) => (
                 <div key={idx} className="bg-zinc-950 border border-zinc-800 p-6 rounded-sm flex flex-col md:flex-row gap-6">
                    <div className="w-32">
                      <span className="text-emerald-500 font-black oswald uppercase text-lg italic">{entry.day}</span>
                    </div>
                    <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-zinc-600 text-[9px] font-black uppercase tracking-widest mb-1 block">Hours</label>
                        <input 
                          className="w-full bg-zinc-900 border border-zinc-800 p-3 text-white text-sm focus:border-emerald-500 outline-none" 
                          value={entry.hours} 
                          onChange={e => updateScheduleEntry(idx, 'hours', e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="text-zinc-600 text-[9px] font-black uppercase tracking-widest mb-1 block">Programming Note</label>
                        <input 
                          className="w-full bg-zinc-900 border border-zinc-800 p-3 text-zinc-500 text-sm focus:border-emerald-500 outline-none" 
                          value={entry.note} 
                          onChange={e => updateScheduleEntry(idx, 'note', e.target.value)}
                        />
                      </div>
                    </div>
                 </div>
               ))}
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="flex justify-end">
                 <button onClick={() => setShowAddReviewModal(true)} className="bg-emerald-600 text-white px-8 py-3 rounded-sm font-black oswald uppercase text-xs hover:bg-emerald-500 transition-all">+ Add Shoutout</button>
               </div>
               <div className="grid grid-cols-1 gap-4">
                 {draftContent.reviews.map((rev, idx) => (
                   <div key={rev.id} className="bg-zinc-950 border border-zinc-800 p-6 rounded-sm flex justify-between items-start group relative">
                      <div className="flex-grow">
                        <div className="flex items-center space-x-3 mb-2">
                           <span className="text-white font-bold oswald uppercase tracking-wider">{rev.name}</span>
                           <span className="text-zinc-600 text-[10px] uppercase font-black">{rev.date}</span>
                        </div>
                        <div className="flex space-x-1 mb-3">
                          {Array.from({length: 5}).map((_, i) => (
                            <i key={i} className={`fa-solid fa-star text-[10px] ${i < rev.rating ? 'text-emerald-500' : 'text-zinc-800'}`}></i>
                          ))}
                        </div>
                        <p className="text-zinc-400 text-sm italic font-light">"{rev.comment}"</p>
                      </div>
                      <button onClick={() => triggerDelete(rev.id, 'review')} className="text-zinc-800 hover:text-red-500 transition-colors pl-6">
                        <i className="fa-solid fa-trash-can text-sm"></i>
                      </button>
                   </div>
                 ))}
               </div>
            </div>
          )}

          {activeTab === 'contact' && (
             <div className="space-y-12 animate-in fade-in duration-300">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                   <div className="space-y-6">
                      <h3 className="text-white font-black oswald text-xl uppercase italic border-b border-zinc-800 pb-2">Business Reach</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-1 block">Reception Hotline</label>
                          <input className="w-full bg-zinc-950 border border-zinc-800 p-4 text-emerald-500 font-black oswald uppercase" value={draftContent.contact.reception} onChange={e => { markChanged(); setDraftContent(prev => ({...prev, contact: {...prev.contact, reception: e.target.value}})) }} />
                        </div>
                        <div>
                          <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-1 block">Owner Office</label>
                          <input className="w-full bg-zinc-950 border border-zinc-800 p-4 text-emerald-500 font-black oswald uppercase" value={draftContent.contact.owner} onChange={e => { markChanged(); setDraftContent(prev => ({...prev, contact: {...prev.contact, owner: e.target.value}})) }} />
                        </div>
                        <div>
                          <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-1 block">Official Address</label>
                          <textarea className="w-full bg-zinc-950 border border-zinc-800 p-4 text-zinc-400 text-sm h-24 resize-none italic" value={draftContent.contact.address} onChange={e => { markChanged(); setDraftContent(prev => ({...prev, contact: {...prev.contact, address: e.target.value}})) }} />
                        </div>
                      </div>
                   </div>
                   <div className="space-y-6">
                      <h3 className="text-white font-black oswald text-xl uppercase italic border-b border-zinc-800 pb-2">Social Channels</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-1 block">Instagram URL</label>
                          <input className="w-full bg-zinc-950 border border-zinc-800 p-4 text-zinc-500 text-xs" value={draftContent.social.instagram} onChange={e => { markChanged(); setDraftContent(prev => ({...prev, social: {...prev.social, instagram: e.target.value}})) }} />
                        </div>
                        <div>
                          <label className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-1 block">Facebook URL</label>
                          <input className="w-full bg-zinc-950 border border-zinc-800 p-4 text-zinc-500 text-xs" value={draftContent.social.facebook} onChange={e => { markChanged(); setDraftContent(prev => ({...prev, social: {...prev.social, facebook: e.target.value}})) }} />
                        </div>
                      </div>
                   </div>
                </div>
             </div>
          )}

          {activeTab === 'inquiries' && (
            <div className="space-y-6 animate-in fade-in duration-300">
               {draftContent.inquiries.length === 0 ? (
                 <div className="py-20 text-center text-zinc-800 font-black uppercase tracking-[0.3em] text-xs italic">Member inbox is empty</div>
               ) : (
                 <div className="grid grid-cols-1 gap-4">
                   {draftContent.inquiries.map(inq => (
                     <div key={inq.id} className="bg-zinc-950 border border-zinc-800 p-6 rounded-sm relative group">
                        <button onClick={() => triggerDelete(inq.id, 'inquiry')} className="absolute top-6 right-6 text-zinc-700 hover:text-red-500 transition-colors">
                          <i className="fa-solid fa-xmark text-lg"></i>
                        </button>
                        <div className="mb-4">
                          <h4 className="text-white font-bold oswald uppercase text-lg tracking-wider">{inq.name}</h4>
                          <span className="text-emerald-500 text-[10px] font-black uppercase tracking-widest">{inq.email} • {inq.date}</span>
                        </div>
                        <p className="text-zinc-400 text-sm border-l-2 border-emerald-900/50 pl-6 py-2 italic font-light">{inq.message}</p>
                     </div>
                   ))}
                 </div>
               )}
            </div>
          )}
        </div>
      </div>

      {/* MODALS */}
      {showSaveConfirmModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-md p-10 rounded-sm shadow-2xl text-center transform animate-in zoom-in-95 duration-200">
            <div className="w-20 h-20 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 border border-emerald-500/20">
              <i className="fa-solid fa-cloud-arrow-up text-3xl"></i>
            </div>
            <h3 className="text-white text-3xl font-black oswald uppercase italic mb-4 tracking-tighter">Publish <span className="text-emerald-500">Live?</span></h3>
            <p className="text-zinc-500 text-sm mb-10 leading-relaxed italic">
              Pushing these modifications will immediately update the live website for all members.
            </p>
            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={handleSaveChanges} 
                className="w-full py-4 bg-emerald-600 text-white font-black uppercase tracking-widest text-xs hover:bg-emerald-500 transition-all shadow-2xl shadow-emerald-900/40"
              >
                Sync Changes Now
              </button>
              <button 
                onClick={() => setShowSaveConfirmModal(false)} 
                className="w-full py-4 bg-zinc-800 text-zinc-500 font-bold uppercase tracking-widest text-[10px] hover:bg-zinc-700 transition-all"
              >
                Continue Editing
              </button>
            </div>
          </div>
        </div>
      )}

      {showConfirmModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-sm p-8 rounded-sm shadow-2xl text-center">
            <h3 className="text-white text-2xl font-black oswald uppercase italic mb-4">Confirm Removal</h3>
            <p className="text-zinc-500 text-sm mb-8 italic leading-relaxed">This item will be cleared from your draft workspace. You must still save changes to apply this permanently.</p>
            <div className="flex gap-4">
              <button onClick={() => setShowConfirmModal(false)} className="flex-1 py-3 bg-zinc-800 text-zinc-400 font-bold uppercase text-[10px] tracking-widest">Cancel</button>
              <button onClick={executeDeletion} className="flex-1 py-3 bg-red-600 text-white font-bold uppercase text-[10px] tracking-widest">Clear Item</button>
            </div>
          </div>
        </div>
      )}

      {showAddTrainerModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md overflow-y-auto">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-2xl p-8 rounded-sm shadow-2xl my-auto animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-4">
              <h3 className="text-white text-3xl font-black oswald uppercase italic tracking-tighter">New <span className="text-emerald-500">Elite Coach</span></h3>
              <button onClick={() => setShowAddTrainerModal(false)} className="text-zinc-500 hover:text-white transition-colors"><i className="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form onSubmit={handleAddTrainer} className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="aspect-square bg-zinc-950 border border-zinc-800 relative group overflow-hidden">
                  <img src={newTrainer.image} className="w-full h-full object-cover" alt="Preview" />
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity" onClick={() => trainerInputRef.current?.click()}>
                    <i className="fa-solid fa-camera text-2xl text-white mb-2"></i>
                    <span className="text-[10px] text-white font-bold uppercase tracking-widest">Upload Profile</span>
                  </div>
                  <input type="file" className="hidden" ref={trainerInputRef} onChange={e => handleFileChange(e, 'new-trainer')} accept="image/*" />
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Full Name</label>
                  <input required className="w-full bg-zinc-950 border border-zinc-800 p-3 text-white text-sm" value={newTrainer.name} onChange={e => setNewTrainer({...newTrainer, name: e.target.value})} placeholder="e.g. Robert Steel" />
                </div>
                <div>
                  <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Specialty</label>
                  <input required className="w-full bg-zinc-950 border border-zinc-800 p-3 text-white text-sm" value={newTrainer.specialty} onChange={e => setNewTrainer({...newTrainer, specialty: e.target.value})} placeholder="e.g. Functional Strength" />
                </div>
                <div>
                  <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Contact</label>
                  <input required className="w-full bg-zinc-950 border border-zinc-800 p-3 text-white text-sm" value={newTrainer.contact} onChange={e => setNewTrainer({...newTrainer, contact: e.target.value})} placeholder="+91 00000 00000" />
                </div>
              </div>
              <div className="md:col-span-2">
                <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Bio</label>
                <textarea required className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-sm h-32 resize-none italic font-light" value={newTrainer.bio} onChange={e => setNewTrainer({...newTrainer, bio: e.target.value})} placeholder="Professional background..."></textarea>
              </div>
              <div className="md:col-span-2 grid grid-cols-2 gap-4 pt-4">
                <button type="button" onClick={() => setShowAddTrainerModal(false)} className="py-4 bg-zinc-800 text-zinc-400 font-bold uppercase tracking-widest text-[10px]">Discard</button>
                <button type="submit" className="py-4 bg-emerald-600 text-white font-black uppercase tracking-widest text-[10px] shadow-xl shadow-emerald-900/20">Register Profile</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAddReviewModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-sm shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-4">
              <h3 className="text-white text-2xl font-black oswald uppercase italic leading-none">Add <span className="text-emerald-500">Shoutout</span></h3>
              <button onClick={() => setShowAddReviewModal(false)} className="text-zinc-500 hover:text-white transition-colors"><i className="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form onSubmit={handleAddReview} className="space-y-6">
              <div>
                <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Athlete Name</label>
                <input required className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-sm" value={newReview.name} onChange={e => setNewReview({...newReview, name: e.target.value})} placeholder="e.g. Marcus Miller" />
              </div>
              <div>
                <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Star Rating (1-5)</label>
                <select className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-sm outline-none" value={newReview.rating} onChange={e => setNewReview({...newReview, rating: parseInt(e.target.value)})}>
                  {[5,4,3,2,1].map(num => <option key={num} value={num}>{num} Stars</option>)}
                </select>
              </div>
              <div>
                <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Comment</label>
                <textarea required className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-sm h-32 resize-none italic" value={newReview.comment} onChange={e => setNewReview({...newReview, comment: e.target.value})} placeholder="Athlete's feedback..."></textarea>
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAddReviewModal(false)} className="flex-1 py-4 bg-zinc-800 text-zinc-400 font-bold uppercase tracking-widest text-[10px]">Discard</button>
                <button type="submit" className="flex-1 py-4 bg-emerald-600 text-white font-bold uppercase tracking-widest text-[10px]">Publish Shoutout</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {saveSuccess && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[110] bg-emerald-600 text-white px-8 py-4 rounded-sm shadow-2xl flex items-center space-x-4 animate-in slide-in-from-bottom-10 border border-emerald-400">
          <i className="fa-solid fa-circle-check text-xl"></i>
          <span className="font-black oswald uppercase italic tracking-widest text-sm">Deployment Successful</span>
        </div>
      )}
    </div>
  );
};

export default Admin;
