
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useContent } from '../context/ContentContext';
import { Review } from '../types';

const Home: React.FC = () => {
  const { content, updateContent } = useContent();

  // Form State
  const [showForm, setShowForm] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [newReview, setNewReview] = useState({
    name: '',
    rating: 5,
    comment: ''
  });
  const [hoveredRating, setHoveredRating] = useState(0);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <i 
        key={i} 
        className={`fa-solid fa-star text-[9px] ${i < rating ? 'text-emerald-500' : 'text-zinc-800'}`}
      ></i>
    ));
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.name || !newReview.comment) return;

    const review: Review = {
      id: 'rev_' + Date.now(),
      name: newReview.name,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toISOString().split('T')[0]
    };

    updateContent(prev => ({
      ...prev,
      reviews: [review, ...(prev.reviews || [])]
    }));

    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setShowForm(false);
      setNewReview({ name: '', rating: 5, comment: '' });
    }, 2500);
  };

  return (
    <div className="bg-zinc-950 min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center z-0 transition-opacity duration-1000" 
          style={{ backgroundImage: `url(${content.hero.backgroundImage})`, filter: 'brightness(0.3)' }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent z-10"></div>
        
        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
          <div className="max-w-2xl animate-in slide-in-from-left duration-700">
            <h2 className="text-emerald-500 text-xl font-bold tracking-[0.3em] uppercase mb-4 neon-text">Good Job Fitness Gym</h2>
            <h1 className="text-white text-6xl md:text-8xl font-black leading-[0.9] oswald mb-6 italic">
              {content.hero.title.split(' ').slice(0, -1).join(' ')} <span className="text-emerald-500">{content.hero.title.split(' ').slice(-1)}</span>
            </h1>
            <p className="text-zinc-300 text-lg md:text-xl leading-relaxed font-light">
              {content.hero.subtitle}
            </p>
          </div>
        </div>
      </section>

      {/* Advantages Section */}
      <section className="py-16 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {content.advantages.slice(0, 3).map((adv) => (
              <div key={adv.id} className="p-6 bg-zinc-900/40 border border-zinc-800 hover:border-emerald-500 transition-all group rounded-sm">
                <div className="flex items-center space-x-4">
                   <i className={`fa-solid ${adv.icon} text-xl text-emerald-500 group-hover:scale-110 transition-transform`}></i>
                   <h3 className="text-sm font-bold text-white uppercase oswald tracking-wide">{adv.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COMPACT REVIEWS SECTION */}
      <section className="py-16 bg-zinc-900/20 border-y border-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-10">
            <div>
              <h2 className="text-2xl font-black text-white uppercase oswald italic tracking-tighter">Member <span className="text-emerald-500">Shoutouts</span></h2>
              <p className="text-zinc-500 text-[8px] font-black uppercase tracking-[0.2em]">Validated Performance Feedback</p>
            </div>
            <button 
              onClick={() => setShowForm(!showForm)}
              className="text-emerald-500 font-black uppercase text-[9px] tracking-widest border border-emerald-500/30 px-4 py-2 hover:bg-emerald-500 hover:text-white transition-all rounded-sm"
            >
              {showForm ? 'Cancel' : '+ Add Review'}
            </button>
          </div>

          {/* Inline Compact Review Form */}
          {showForm && (
            <div className="mb-10 animate-in slide-in-from-top duration-300">
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
                {formSubmitted ? (
                  <div className="text-center py-4 text-emerald-500 text-xs font-bold uppercase tracking-widest">Review Published Successfully</div>
                ) : (
                  <form onSubmit={handleReviewSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex flex-col justify-center items-center md:items-start">
                      <div className="flex space-x-1 mb-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onMouseEnter={() => setHoveredRating(star)}
                            onMouseLeave={() => setHoveredRating(0)}
                            onClick={() => setNewReview({ ...newReview, rating: star })}
                          >
                            <i className={`fa-solid fa-star text-sm ${star <= (hoveredRating || newReview.rating) ? 'text-emerald-500' : 'text-zinc-800'}`}></i>
                          </button>
                        ))}
                      </div>
                      <span className="text-[8px] text-zinc-600 font-black uppercase">Rate Us</span>
                    </div>
                    <div className="md:col-span-2 flex flex-col sm:flex-row gap-3">
                      <input 
                        required 
                        placeholder="Your Name" 
                        className="bg-zinc-950 border border-zinc-800 p-3 text-xs text-white focus:border-emerald-500 outline-none w-full sm:w-1/3"
                        value={newReview.name}
                        onChange={e => setNewReview({ ...newReview, name: e.target.value })}
                      />
                      <input 
                        required 
                        placeholder="Your feedback..." 
                        className="bg-zinc-950 border border-zinc-800 p-3 text-xs text-white focus:border-emerald-500 outline-none flex-grow"
                        value={newReview.comment}
                        onChange={e => setNewReview({ ...newReview, comment: e.target.value })}
                      />
                      <button type="submit" className="bg-emerald-600 text-white font-bold text-[9px] uppercase px-6 py-3 hover:bg-emerald-500 transition-colors">Post</button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {content.reviews && content.reviews.slice(0, 3).map((review) => (
              <div key={review.id} className="bg-zinc-900/50 border border-zinc-800 p-5 rounded-sm flex flex-col hover:border-emerald-500/30 transition-all">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex space-x-0.5">{renderStars(review.rating)}</div>
                  <span className="text-zinc-600 text-[7px] font-black uppercase">{review.date}</span>
                </div>
                <p className="text-zinc-300 text-xs italic font-light leading-snug mb-4 line-clamp-2">"{review.comment}"</p>
                <div className="flex items-center space-x-3 mt-auto border-t border-zinc-800/50 pt-3">
                  <div className="w-6 h-6 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center text-[9px] font-bold">{review.name.charAt(0)}</div>
                  <span className="text-white font-bold oswald uppercase text-[10px] tracking-wide">{review.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WEEKLY SCHEDULE TABLE SECTION */}
      <section className="py-20 bg-zinc-950 border-b border-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div>
              <h2 className="text-3xl font-black text-white uppercase oswald italic tracking-tighter leading-none">Weekly <span className="text-emerald-500">Timeline</span></h2>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] mt-3">Operational Schedule & Programming</p>
            </div>
            <div className="flex items-center space-x-4 bg-zinc-900 border border-zinc-800 px-6 py-3 rounded-sm">
              <i className="fa-solid fa-clock text-emerald-500"></i>
              <span className="text-white font-black oswald text-sm uppercase tracking-widest italic">06:00 AM - 10:00 PM (Weekdays)</span>
            </div>
          </div>
          
          <div className="overflow-x-auto border border-zinc-900 rounded-sm">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-zinc-900/80 border-b border-zinc-800">
                  <th className="p-5 oswald text-emerald-500 text-xs tracking-[0.2em] font-black uppercase">Day of Week</th>
                  <th className="p-5 oswald text-emerald-500 text-xs tracking-[0.2em] font-black uppercase">Working Hours</th>
                  <th className="p-5 oswald text-emerald-500 text-xs tracking-[0.2em] font-black uppercase">Facility Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-900">
                {content.schedule.map((entry, idx) => (
                  <tr key={idx} className="hover:bg-zinc-900/40 transition-colors group">
                    <td className="p-5 text-white font-bold oswald text-base tracking-wide italic">{entry.day}</td>
                    <td className="p-5">
                      <span className="text-zinc-100 font-black oswald text-sm tracking-widest bg-emerald-600/10 border border-emerald-500/20 px-3 py-1 rounded-sm group-hover:border-emerald-500 transition-colors">
                        {entry.hours}
                      </span>
                    </td>
                    <td className="p-5">
                      <p className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest italic flex items-center">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2 opacity-50"></span>
                        {entry.note}
                      </p>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-zinc-900/50 border border-zinc-800 p-6 flex items-center space-x-4">
              <div className="w-10 h-10 bg-emerald-500/10 rounded flex items-center justify-center text-emerald-500">
                <i className="fa-solid fa-bolt"></i>
              </div>
              <div>
                <p className="text-white font-black oswald text-xs uppercase tracking-widest">Early Bird</p>
                <p className="text-zinc-500 text-[9px] uppercase">Starts 06:00 AM</p>
              </div>
            </div>
            <div className="bg-zinc-900/50 border border-zinc-800 p-6 flex items-center space-x-4">
              <div className="w-10 h-10 bg-emerald-500/10 rounded flex items-center justify-center text-emerald-500">
                <i className="fa-solid fa-moon"></i>
              </div>
              <div>
                <p className="text-white font-black oswald text-xs uppercase tracking-widest">Night Session</p>
                <p className="text-zinc-500 text-[9px] uppercase">Until 10:00 PM</p>
              </div>
            </div>
            <div className="bg-emerald-600 p-6 flex items-center justify-center space-x-4 cursor-pointer hover:bg-emerald-500 transition-colors rounded-sm">
              <i className="fa-solid fa-id-card text-white text-xl"></i>
              <span className="text-white font-black oswald text-sm uppercase tracking-widest italic">Join Today</span>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-24 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img src={content.about.image} alt="Gym Facility" className="rounded-lg shadow-2xl relative z-10 neon-border aspect-video object-cover w-full opacity-80" />
              <div className="absolute -bottom-4 -right-4 bg-emerald-600 p-5 hidden md:block z-20 shadow-xl">
                <p className="text-white text-3xl font-black italic oswald tracking-tighter">24/7</p>
                <p className="text-white/80 uppercase tracking-widest text-[8px] font-bold">Facility Access</p>
              </div>
            </div>
            <div>
              <h4 className="text-emerald-500 font-bold uppercase tracking-[0.3em] mb-4 text-xs">{content.about.title}</h4>
              <h2 className="text-white text-4xl font-black uppercase oswald italic mb-6">
                {content.about.subtitle.split(' ').slice(0, -1).join(' ')} <span className="text-emerald-500">{content.about.subtitle.split(' ').slice(-1)}</span>
              </h2>
              <p className="text-zinc-400 leading-relaxed text-sm mb-8 font-light italic">
                {content.about.description}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center space-x-2 text-white font-bold">
                  <i className="fa-solid fa-check-double text-emerald-500 text-[10px]"></i>
                  <span className="text-[10px] uppercase tracking-wider">Premium Equipment</span>
                </div>
                <div className="flex items-center space-x-2 text-white font-bold">
                  <i className="fa-solid fa-check-double text-emerald-500 text-[10px]"></i>
                  <span className="text-[10px] uppercase tracking-wider">Zero Training Barriers</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section Preview */}
      <section className="py-24 bg-zinc-900/10 border-t border-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
            <div>
              <h2 className="text-4xl font-black text-white uppercase oswald italic mb-2 tracking-tighter">Gym <span className="text-emerald-500">Ambience</span></h2>
              <p className="text-zinc-500 text-sm uppercase tracking-[0.3em] font-bold">Explore our world-class facility</p>
            </div>
            <Link to="/gallery" className="text-emerald-500 font-black uppercase text-[10px] tracking-widest border-b border-emerald-500/50 hover:text-white hover:border-white transition-all pb-1">
              View All Photos <i className="fa-solid fa-arrow-right ml-2"></i>
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {content.gallery && content.gallery.length > 0 ? (
              content.gallery.slice(0, 4).map((img) => (
                <div key={img.id} className="relative group overflow-hidden bg-zinc-900 aspect-square rounded-sm">
                  <img 
                    src={img.url} 
                    alt="Ambience" 
                    className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 group-hover:scale-110" 
                  />
                  <div className="absolute inset-0 bg-emerald-900/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-20 text-center border border-zinc-900">
                <p className="text-zinc-700 font-bold uppercase tracking-widest italic">Gallery images coming soon...</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
