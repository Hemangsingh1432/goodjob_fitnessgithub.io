import React, { useState } from 'react';

const Membership: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    plan: 'Pro Strategy'
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="bg-zinc-950 min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Benefits Content */}
          <div className="space-y-12">
            <div>
              <h1 className="text-emerald-500 font-bold uppercase tracking-[0.3em] mb-4 text-sm">Member Benefits</h1>
              <h2 className="text-white text-5xl md:text-6xl font-black uppercase oswald italic mb-8 leading-tight">Join The <span className="text-emerald-500">Movement</span></h2>
              <p className="text-zinc-400 text-lg font-light leading-relaxed">
                Membership at Energy Fitness Gym gives you more than just a place to sweat. You get a community of like-minded individuals focused on growth and a facility designed to maximize your efficiency.
              </p>
            </div>

            <div className="space-y-8">
              {[
                { icon: 'fa-clock', title: '24/7 Unlimited Access', desc: 'Train whenever inspiration strikes. Our facility is open round-the-clock for your convenience.' },
                { icon: 'fa-users', title: 'Group Training Classes', desc: 'Access over 50+ classes weekly, ranging from high-octane HIIT to focused powerlifting clinics.' },
                { icon: 'fa-apple-whole', title: 'Nutrition Guidance', desc: 'Get expert dietary advice to fuel your body correctly for the gains you deserve.' }
              ].map((item, idx) => (
                <div key={idx} className="flex items-start space-x-6">
                  <div className="bg-zinc-900 p-4 border border-zinc-800 text-emerald-500 text-2xl rounded group hover:border-emerald-500 transition-colors">
                    <i className={`fa-solid ${item.icon}`}></i>
                  </div>
                  <div>
                    <h3 className="text-white font-bold uppercase oswald text-xl mb-2 tracking-wide">{item.title}</h3>
                    <p className="text-zinc-500 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Join Form Card */}
          <div className="bg-zinc-900 border border-zinc-800 p-8 md:p-12 shadow-2xl relative rounded-sm">
            {submitted ? (
              <div className="text-center py-20 animate-in zoom-in duration-300">
                <i className="fa-solid fa-circle-check text-emerald-500 text-7xl mb-6"></i>
                <h3 className="text-white text-3xl font-black uppercase oswald italic mb-4">Welcome To The Team!</h3>
                <p className="text-zinc-400 mb-8 max-w-xs mx-auto">Your application has been received. Our team will contact you within 24 hours to complete your registration.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="bg-emerald-600 text-white px-10 py-4 font-bold uppercase tracking-widest text-sm rounded-sm hover:bg-emerald-700 transition-all"
                >
                  Close
                </button>
              </div>
            ) : (
              <>
                <h3 className="text-white text-3xl font-black uppercase oswald italic mb-8">Claim Your <span className="text-emerald-500">Free Trial</span></h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-zinc-500 uppercase text-xs font-bold mb-2 tracking-widest">Full Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-zinc-800 border border-zinc-700 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm"
                      placeholder="e.g. John Doe"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-zinc-500 uppercase text-xs font-bold mb-2 tracking-widest">Email Address</label>
                      <input 
                        required
                        type="email" 
                        className="w-full bg-zinc-800 border border-zinc-700 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-zinc-500 uppercase text-xs font-bold mb-2 tracking-widest">Phone Number</label>
                      <input 
                        required
                        type="tel" 
                        className="w-full bg-zinc-800 border border-zinc-700 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm"
                        placeholder="(555) 000-0000"
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-zinc-500 uppercase text-xs font-bold mb-2 tracking-widest">Interested Plan</label>
                    <select 
                      className="w-full bg-zinc-800 border border-zinc-700 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm appearance-none"
                      value={formData.plan}
                      onChange={e => setFormData({...formData, plan: e.target.value})}
                    >
                      <option>Basic Plan</option>
                      <option>Pro Strategy</option>
                      <option>Elite Performance</option>
                    </select>
                  </div>
                  <button 
                    type="submit" 
                    className="w-full bg-emerald-600 text-white font-black uppercase tracking-[0.2em] py-5 text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-600/20"
                  >
                    Get Started Now
                  </button>
                  <p className="text-zinc-500 text-[10px] text-center uppercase tracking-widest font-bold mt-4 opacity-60">Join the elite energy network</p>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Membership;