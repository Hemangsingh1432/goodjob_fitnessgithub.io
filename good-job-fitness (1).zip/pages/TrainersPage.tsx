
import React from 'react';
import { useContent } from '../context/ContentContext';

const TrainersPage: React.FC = () => {
  const { content } = useContent();

  return (
    <div className="bg-zinc-950 min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h1 className="text-emerald-500 font-bold uppercase tracking-[0.3em] mb-4 text-sm">Our Specialist Team</h1>
          <h2 className="text-white text-5xl md:text-7xl font-black uppercase oswald italic mb-8">Professional <span className="text-emerald-500">Coaches</span></h2>
          <p className="text-zinc-400 max-w-2xl mx-auto text-lg font-light">Meet the experts dedicated to your physical evolution.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {content.trainers.map((trainer) => (
            <div key={trainer.id} className="bg-zinc-900 border border-zinc-800 hover:border-emerald-500 transition-all duration-300 rounded-sm overflow-hidden flex flex-col h-full group">
              <div className="aspect-square overflow-hidden relative">
                <img src={trainer.image} alt={trainer.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 to-transparent"></div>
              </div>
              <div className="p-8 flex flex-col flex-grow">
                <div className="mb-6">
                  <h3 className="text-white text-2xl font-black uppercase oswald mb-1 tracking-wide">{trainer.name}</h3>
                  <p className="text-emerald-500 font-bold uppercase text-[10px] tracking-[0.3em]">{trainer.specialty}</p>
                </div>
                <p className="text-zinc-400 text-sm italic font-light leading-relaxed mb-8 flex-grow border-l border-emerald-500/30 pl-4">
                  {trainer.bio}
                </p>
                <div className="pt-6 border-t border-zinc-800">
                  <p className="text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-2">Direct Contact</p>
                  <a href={`tel:${trainer.contact}`} className="text-white font-bold hover:text-emerald-400 transition-colors flex items-center">
                    <i className="fa-solid fa-phone text-xs mr-2 text-emerald-500"></i>
                    {trainer.contact}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrainersPage;
