
import React, { useState, useMemo } from 'react';
import { useContent } from '../context/ContentContext';
import { Athlete, AttendanceRecord } from '../types';

const AttendancePortal: React.FC = () => {
  const { content, updateContent } = useContent();
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  
  // Tab control
  const [activeTab, setActiveTab] = useState<'checkin' | 'athletes' | 'history'>('checkin');
  
  // Modals for Member Management
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [athleteToDelete, setAthleteToDelete] = useState<Athlete | null>(null);
  
  // New Member Form State
  const [newMemberData, setNewMemberData] = useState({
    name: '',
    plan: 'Basic'
  });

  // Date tracking
  const today = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(today);

  // Global Tracking Stats
  const totalTrackedDates = useMemo(() => {
    const dates = new Set((content.attendance || []).map(r => r.date));
    return dates.size || 1; 
  }, [content.attendance]);

  // Stats
  const stats = useMemo(() => {
    const dailyRecords = (content.attendance || []).filter(r => r.date === selectedDate);
    return {
      total: content.athletes.length,
      present: dailyRecords.filter(r => r.status === 'present').length,
    };
  }, [content.athletes, content.attendance, selectedDate]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Static key check for 1978
    if (passwordInput === '1978' || passwordInput === content.portalPassword) {
      setIsUnlocked(true);
    } else {
      alert('Unauthorized Access: Incorrect Security Key');
    }
  };

  const toggleAttendance = (athleteId: string) => {
    updateContent(prev => {
      const existingIdx = (prev.attendance || []).findIndex(r => r.date === selectedDate && r.athleteId === athleteId);
      let newAttendance = [...(prev.attendance || [])];

      if (existingIdx > -1) {
        const currentStatus = newAttendance[existingIdx].status;
        if (currentStatus === 'present') {
          newAttendance[existingIdx].status = 'absent';
        } else {
          newAttendance.splice(existingIdx, 1);
        }
      } else {
        newAttendance.push({ date: selectedDate, athleteId, status: 'present' });
      }

      return { ...prev, attendance: newAttendance };
    });
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberData.name) return;

    const newAthlete: Athlete = {
      id: 'ath_' + Date.now(),
      name: newMemberData.name,
      membershipPlan: newMemberData.plan,
      joinDate: new Date().toISOString().split('T')[0],
      status: 'active'
    };

    updateContent(prev => ({ ...prev, athletes: [...prev.athletes, newAthlete] }));
    setShowAddMemberModal(false);
    setNewMemberData({ name: '', plan: 'Basic' });
  };

  const confirmDeleteMember = (athlete: Athlete) => {
    setAthleteToDelete(athlete);
    setShowDeleteConfirmModal(true);
  };

  const executeDeleteMember = () => {
    if (!athleteToDelete) return;
    updateContent(prev => ({
      ...prev,
      athletes: prev.athletes.filter(a => a.id !== athleteToDelete.id),
      attendance: (prev.attendance || []).filter(r => r.athleteId !== athleteToDelete.id)
    }));
    setShowDeleteConfirmModal(false);
    setAthleteToDelete(null);
  };

  const getAthleteStats = (athleteId: string) => {
    const records = (content.attendance || []).filter(r => r.athleteId === athleteId && r.status === 'present');
    const days = records.length;
    const percentage = totalTrackedDates > 0 ? Math.round((days / totalTrackedDates) * 100) : 0;
    return { days, percentage };
  };

  return (
    <div className="min-h-screen bg-zinc-950">
      {!isUnlocked ? (
        <div className="min-h-screen flex flex-col items-center justify-center p-6 pt-32">
          <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 p-10 rounded-sm shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500"></div>
            
            <form onSubmit={handleLogin} className="space-y-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
                  <i className="fa-solid fa-id-card-clip text-emerald-500 text-2xl"></i>
                </div>
                <h2 className="text-white text-3xl font-black oswald uppercase italic leading-none mb-2 tracking-tighter">STAFF <span className="text-emerald-500">GATEWAY</span></h2>
                <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest italic">Protected Attendance System</p>
              </div>

              <div className="space-y-4">
                <div className="relative">
                  <i className="fa-solid fa-key absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600"></i>
                  <input 
                    type="password" 
                    placeholder="Enter Security Key" 
                    className="w-full bg-zinc-950 border border-zinc-800 p-4 pl-12 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-700 font-mono"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    autoFocus
                  />
                </div>
                <button className="w-full bg-emerald-600 text-white font-black py-4 hover:bg-emerald-700 transition-all uppercase tracking-widest text-sm shadow-xl shadow-emerald-900/20">Access Gateway</button>
              </div>
              
              <div className="text-center">
                <p className="text-zinc-700 text-[8px] font-black uppercase tracking-widest italic">Authorized Staff Only</p>
              </div>
            </form>
          </div>
        </div>
      ) : (
        <div className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          {/* Header Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm relative group overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 -mr-8 -mt-8 rounded-full"></div>
              <p className="text-zinc-500 text-[9px] font-black uppercase tracking-widest mb-1">Today's Check-ins</p>
              <div className="flex items-baseline space-x-2">
                <span className="text-4xl font-black text-emerald-500 oswald tracking-tighter">{stats.present}</span>
                <span className="text-zinc-600 text-sm">/ {stats.total} Athletes</span>
              </div>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-sm">
              <p className="text-zinc-500 text-[9px] font-black uppercase tracking-widest mb-1">Attendance Date</p>
              <input 
                type="date" 
                className="bg-transparent text-white font-bold oswald text-xl outline-none"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
            </div>
            <div className="flex items-center justify-end">
              <button onClick={() => setIsUnlocked(false)} className="text-zinc-600 hover:text-white font-black uppercase tracking-widest text-[10px] flex items-center transition-colors">
                <i className="fa-solid fa-power-off mr-2"></i> Lock Gateway
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-6 mb-10 border-b border-zinc-900">
            <button 
              onClick={() => setActiveTab('checkin')}
              className={`pb-4 px-2 font-bold uppercase text-[10px] tracking-widest transition-all relative ${activeTab === 'checkin' ? 'text-emerald-500' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              Check-In Desk
              {activeTab === 'checkin' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-emerald-500"></div>}
            </button>
            <button 
              onClick={() => setActiveTab('athletes')}
              className={`pb-4 px-2 font-bold uppercase text-[10px] tracking-widest transition-all relative ${activeTab === 'athletes' ? 'text-emerald-500' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              Member Database
              {activeTab === 'athletes' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-emerald-500"></div>}
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`pb-4 px-2 font-bold uppercase text-[10px] tracking-widest transition-all relative ${activeTab === 'history' ? 'text-emerald-500' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              Audit History
              {activeTab === 'history' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-emerald-500"></div>}
            </button>
          </div>

          {/* Tab Content Area */}
          <div className="bg-zinc-900/30 border border-zinc-800/50 p-6 md:p-8 rounded-sm">
            {activeTab === 'checkin' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-white text-2xl font-black oswald uppercase italic leading-none tracking-tighter">Daily <span className="text-emerald-500">Check-In</span></h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {content.athletes.map(athlete => {
                    const record = (content.attendance || []).find(r => r.date === selectedDate && r.athleteId === athlete.id);
                    const isPresent = record?.status === 'present';
                    const isAbsent = record?.status === 'absent';
                    const { days, percentage } = getAthleteStats(athlete.id);

                    return (
                      <div 
                        key={athlete.id}
                        onClick={() => toggleAttendance(athlete.id)}
                        className={`p-5 border rounded-sm cursor-pointer transition-all flex flex-col group ${
                          isPresent ? 'bg-emerald-600/10 border-emerald-500 shadow-lg shadow-emerald-500/5' : 
                          isAbsent ? 'bg-red-600/10 border-red-500/50' : 
                          'bg-zinc-900 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                            isPresent ? 'bg-emerald-500 text-white' : 
                            isAbsent ? 'bg-red-600 text-white' : 
                            'bg-zinc-950 text-zinc-700 group-hover:text-zinc-400'
                          }`}>
                            <i className={`fa-solid ${isPresent ? 'fa-check' : isAbsent ? 'fa-xmark' : 'fa-fingerprint'}`}></i>
                          </div>
                          <div className="text-right">
                            <p className="text-zinc-500 text-[8px] font-black uppercase tracking-widest">Rate</p>
                            <p className={`text-[10px] font-bold ${percentage > 70 ? 'text-emerald-500' : 'text-zinc-400'}`}>{percentage}%</p>
                          </div>
                        </div>
                        
                        <div>
                          <p className={`font-bold uppercase oswald text-base leading-tight tracking-wide ${isPresent ? 'text-white' : 'text-zinc-300'}`}>{athlete.name}</p>
                          <p className="text-zinc-600 text-[8px] font-black uppercase tracking-widest mt-1">Total: {days} Days</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            
            {activeTab === 'athletes' && (
              <div className="space-y-8">
                 <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-6">
                  <div>
                    <h3 className="text-white text-2xl font-black oswald uppercase italic leading-none tracking-tighter">Member <span className="text-emerald-500">Roster</span></h3>
                    <p className="text-zinc-500 text-[9px] font-black uppercase tracking-widest mt-1 italic">Total {content.athletes.length} Active Members • Auditing {totalTrackedDates} Days</p>
                  </div>
                  <button 
                    onClick={() => setShowAddMemberModal(true)}
                    className="bg-emerald-600 text-white text-[10px] font-black py-3 px-8 uppercase tracking-widest hover:bg-emerald-500 transition-all rounded-sm shadow-xl shadow-emerald-900/10"
                  >
                    Register New Member
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-zinc-800">
                        <th className="py-4 text-zinc-500 text-[9px] font-black uppercase tracking-widest">Athlete Profile</th>
                        <th className="py-4 text-zinc-500 text-[9px] font-black uppercase tracking-widest">Total Days</th>
                        <th className="py-4 text-zinc-500 text-[9px] font-black uppercase tracking-widest">Success Rate</th>
                        <th className="py-4 text-zinc-500 text-[9px] font-black uppercase tracking-widest">Status</th>
                        <th className="py-4 text-zinc-500 text-[9px] font-black uppercase tracking-widest text-right">Settings</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900">
                      {content.athletes.map(athlete => {
                        const { days, percentage } = getAthleteStats(athlete.id);
                        return (
                          <tr key={athlete.id} className="group hover:bg-zinc-950/50">
                            <td className="py-4">
                              <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-emerald-500 text-xs font-bold uppercase">
                                  {athlete.name.charAt(0)}
                                </div>
                                <div>
                                  <span className="text-white font-bold text-sm block tracking-tight">{athlete.name}</span>
                                  <span className="text-zinc-600 text-[8px] font-black uppercase tracking-widest">{athlete.membershipPlan}</span>
                                </div>
                              </div>
                            </td>
                            <td className="py-4">
                              <div className="flex items-center space-x-2">
                                <i className="fa-solid fa-calendar-check text-emerald-500/50 text-[10px]"></i>
                                <span className="text-white font-mono text-sm">{days}</span>
                              </div>
                            </td>
                            <td className="py-4">
                              <div className="w-24 bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full transition-all duration-500 ${percentage > 70 ? 'bg-emerald-500' : percentage > 40 ? 'bg-amber-500' : 'bg-red-500'}`} 
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                              <span className="text-zinc-400 text-[10px] font-bold mt-1 block">{percentage}%</span>
                            </td>
                            <td className="py-4">
                              <span className="px-3 py-1 bg-emerald-950/50 text-emerald-500 text-[9px] font-black uppercase tracking-widest rounded-full border border-emerald-900/30">Active</span>
                            </td>
                            <td className="py-4 text-right">
                              <button 
                                onClick={() => confirmDeleteMember(athlete)}
                                className="text-zinc-600 hover:text-red-500 transition-colors p-2"
                              >
                                <i className="fa-solid fa-trash-can text-sm"></i>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'history' && (
               <div className="space-y-6">
                 <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-6">
                   <h3 className="text-white text-2xl font-black oswald uppercase italic leading-none tracking-tighter">Activity <span className="text-emerald-500">Audit</span></h3>
                   <p className="text-zinc-500 text-[9px] font-black uppercase tracking-widest">Entry Logs</p>
                 </div>
                 <div className="space-y-3">
                   {[...(content.attendance || [])].reverse().slice(0, 50).map((log, idx) => {
                     const athlete = content.athletes.find(a => a.id === log.athleteId);
                     return (
                       <div key={idx} className="p-4 bg-zinc-950 border border-zinc-800 rounded-sm flex items-center justify-between text-[10px] font-bold uppercase tracking-widest group hover:border-emerald-500/30 transition-all">
                         <div className="flex items-center space-x-4">
                            <span className="text-zinc-600 bg-zinc-900 px-3 py-1 rounded-sm border border-zinc-800">{log.date}</span>
                            <span className="text-white oswald text-sm tracking-normal italic font-medium">{athlete?.name || 'Removed Member'}</span>
                         </div>
                         <span className={log.status === 'present' ? 'text-emerald-500' : 'text-red-500'}>
                           <i className={`fa-solid ${log.status === 'present' ? 'fa-circle-check' : 'fa-circle-xmark'} mr-2`}></i>
                           {log.status === 'present' ? 'Checked In' : 'Absent'}
                         </span>
                       </div>
                     );
                   })}
                 </div>
               </div>
            )}
          </div>
        </div>
      )}

      {/* MODALS */}
      {showDeleteConfirmModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-sm p-8 rounded-sm shadow-2xl text-center transform animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-red-600/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fa-solid fa-user-minus text-2xl"></i>
            </div>
            <h3 className="text-white text-2xl font-black oswald uppercase italic mb-3">Remove <span className="text-red-500">Athlete</span></h3>
            <p className="text-zinc-400 text-sm mb-8 leading-relaxed italic">
              Are you sure you want to remove <span className="text-white font-bold">{athleteToDelete?.name}</span>?
            </p>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setShowDeleteConfirmModal(false)} className="py-3 bg-zinc-800 text-zinc-400 font-bold uppercase tracking-widest text-[10px] hover:bg-zinc-700 transition-all">Cancel</button>
              <button onClick={executeDeleteMember} className="py-3 bg-red-600 text-white font-bold uppercase tracking-widest text-[10px] hover:bg-red-700 transition-all shadow-lg shadow-red-900/20">Confirm Delete</button>
            </div>
          </div>
        </div>
      )}

      {showAddMemberModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-md p-8 rounded-sm shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-4">
              <h3 className="text-white text-2xl font-black oswald uppercase italic leading-none">New <span className="text-emerald-500">Registration</span></h3>
              <button onClick={() => setShowAddMemberModal(false)} className="text-zinc-500 hover:text-white transition-colors"><i className="fa-solid fa-xmark text-xl"></i></button>
            </div>
            <form onSubmit={handleAddMember} className="space-y-6">
              <div>
                <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Athlete Name</label>
                <input required className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-sm focus:ring-1 focus:ring-emerald-500 outline-none" placeholder="e.g. Marcus Aurelius" value={newMemberData.name} onChange={e => setNewMemberData({...newMemberData, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-zinc-500 text-[10px] uppercase font-black tracking-widest mb-1">Membership Tier</label>
                <select className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white text-sm focus:ring-1 focus:ring-emerald-500 outline-none" value={newMemberData.plan} onChange={e => setNewMemberData({...newMemberData, plan: e.target.value})} >
                  <option value="Basic">Basic Plan</option>
                  <option value="Pro">Pro Strategy</option>
                  <option value="Elite">Elite Performance</option>
                </select>
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAddMemberModal(false)} className="flex-1 py-4 bg-zinc-800 text-zinc-400 font-bold uppercase tracking-widest text-[10px] hover:bg-zinc-700 transition-all">Discard</button>
                <button type="submit" className="flex-1 py-4 bg-emerald-600 text-white font-bold uppercase tracking-widest text-[10px] hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-900/20">Confirm Registration</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendancePortal;
