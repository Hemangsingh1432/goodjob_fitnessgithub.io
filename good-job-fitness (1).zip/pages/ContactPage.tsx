
import React, { useState } from 'react';
import { useContent } from '../context/ContentContext';
import { Inquiry } from '../types';

const ContactPage: React.FC = () => {
  const { content, updateContent } = useContent();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    const newInquiry: Inquiry = {
      id: Date.now().toString(),
      ...formData,
      date: new Date().toLocaleString()
    };

    updateContent({
      ...content,
      inquiries: [newInquiry, ...(content.inquiries || [])]
    });

    setSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
    
    // Reset success message after 5 seconds
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="bg-zinc-950 min-h-screen pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h1 className="text-emerald-500 font-bold uppercase tracking-[0.3em] mb-4 text-sm">Support & Information</h1>
          <h2 className="text-white text-5xl md:text-7xl font-black uppercase oswald italic mb-8">Reach the <span className="text-emerald-500">Team</span></h2>
          <p className="text-zinc-400 max-w-2xl mx-auto text-lg font-light">Dedicated support for our members and business inquiries.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="bg-zinc-900 border border-zinc-800 p-10 rounded-sm">
              <h3 className="text-white text-3xl font-black uppercase oswald italic mb-10 border-b border-zinc-800 pb-4 tracking-tighter">Official Contacts</h3>
              <div className="space-y-12">
                <div className="flex items-start space-x-6 group">
                  <div className="w-14 h-14 bg-emerald-500/10 rounded flex items-center justify-center text-emerald-500 flex-shrink-0">
                    <i className="fa-solid fa-headset text-2xl"></i>
                  </div>
                  <div>
                    <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-2">Reception Desk</h4>
                    <a href={`tel:${content.contact.reception}`} className="text-emerald-400 text-xl font-black oswald tracking-widest hover:text-white transition-all">{content.contact.reception}</a>
                  </div>
                </div>
                <div className="flex items-start space-x-6 group">
                  <div className="w-14 h-14 bg-emerald-500/10 rounded flex items-center justify-center text-emerald-500 flex-shrink-0">
                    <i className="fa-solid fa-user-tie text-2xl"></i>
                  </div>
                  <div>
                    <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-2">Owner's Office</h4>
                    <a href={`tel:${content.contact.owner}`} className="text-emerald-400 text-xl font-black oswald tracking-widest hover:text-white transition-all">{content.contact.owner}</a>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-10 rounded-sm">
              <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-6 text-emerald-500">Facility Location</h4>
              <p className="text-zinc-300 text-lg font-light italic">{content.contact.address}</p>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 p-10 md:p-12 rounded-sm h-full relative">
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center py-20 text-center animate-in zoom-in duration-300">
                <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mb-6">
                  <i className="fa-solid fa-check text-emerald-500 text-3xl"></i>
                </div>
                <h3 className="text-white text-2xl font-black oswald uppercase italic mb-4">Message Received</h3>
                <p className="text-zinc-400 max-w-xs mx-auto text-sm leading-relaxed italic">
                  Thank you for your inquiry. Our management team will review your message and get back to you shortly.
                </p>
                <button onClick={() => setSubmitted(false)} className="mt-8 text-emerald-500 text-[10px] font-bold uppercase tracking-widest hover:text-white transition-colors">Send another message</button>
              </div>
            ) : (
              <>
                <h3 className="text-white text-3xl font-black uppercase oswald mb-10 italic">Quick <span className="text-emerald-500">Inquiry</span></h3>
                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <input 
                      type="text" 
                      required
                      className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm" 
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                    />
                    <input 
                      type="email" 
                      required
                      className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm" 
                      placeholder="Your Email"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  <textarea 
                    rows={8} 
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 p-4 text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-sm resize-none" 
                    placeholder="How can we help you?"
                    value={formData.message}
                    onChange={e => setFormData({ ...formData, message: e.target.value })}
                  ></textarea>
                  <button type="submit" className="w-full bg-emerald-600 text-white font-black uppercase py-5 text-sm hover:bg-white hover:text-black transition-all rounded-sm">Send Message</button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
