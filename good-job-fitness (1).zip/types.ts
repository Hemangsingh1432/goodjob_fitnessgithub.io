
export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  recommended?: boolean;
}

export interface Trainer {
  id: string;
  name: string;
  specialty: string;
  image: string;
  bio: string;
  contact: string;
}

export interface Advantage {
  id: string;
  title: string;
  icon: string;
  desc: string;
}

export interface ContactInfo {
  reception: string;
  owner: string;
  address: string;
  email: string;
}

export interface Inquiry {
  id: string;
  name: string;
  email: string;
  message: string;
  date: string;
}

export interface GalleryImage {
  id: string;
  url: string;
  caption?: string;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Athlete {
  id: string;
  name: string;
  membershipPlan: string;
  joinDate: string;
  status: 'active' | 'expired';
}

export interface AttendanceRecord {
  date: string; // YYYY-MM-DD
  athleteId: string;
  status: 'present' | 'absent';
}

export interface ScheduleEntry {
  day: string;
  hours: string;
  note: string;
}

export interface SiteContent {
  pricing: PricingPlan[];
  trainers: Trainer[];
  advantages: Advantage[];
  contact: ContactInfo;
  inquiries: Inquiry[];
  gallery: GalleryImage[];
  athletes: Athlete[];
  attendance: AttendanceRecord[];
  reviews: Review[];
  schedule: ScheduleEntry[];
  portalPassword?: string;
  social: {
    facebook: string;
    instagram: string;
  };
  hero: {
    title: string;
    subtitle: string;
    backgroundImage: string;
  };
  about: {
    title: string;
    subtitle: string;
    description: string;
    image: string;
  };
}
