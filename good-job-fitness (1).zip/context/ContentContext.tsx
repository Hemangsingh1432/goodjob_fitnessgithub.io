
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteContent, PricingPlan, Trainer, ContactInfo, Advantage, GalleryImage, Athlete, AttendanceRecord, Review, ScheduleEntry } from '../types';

interface ContentContextType {
  content: SiteContent;
  updateContent: (newContentOrFn: SiteContent | ((prev: SiteContent) => SiteContent)) => void;
  resetToDefault: () => void;
}

const defaultContent: SiteContent = {
  hero: {
    title: "UPGRADE YOUR POTENTIAL",
    subtitle: "Experience the highest standard of physical training. No restrictions, no excuses. Just professional grade results.",
    backgroundImage: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop'
  },
  about: {
    title: "Professional Fitness",
    subtitle: "No Limits. Just Performance",
    description: "We provide a zero-restriction environment. Whether you train at midnight or noon, you have full access to every machine and every training plan.",
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1200&auto=format&fit=crop'
  },
  advantages: [
    { id: '1', title: 'Modern Equipment', icon: 'fa-dumbbell', desc: 'Access to the latest fitness technology and heavy-duty weights.' },
    { id: '2', title: 'Expert Coaching', icon: 'fa-user-tie', desc: 'Learn from certified trainers dedicated to your performance.' },
    { id: '3', title: 'Hygienic Space', icon: 'fa-sparkles', desc: 'We maintain professional cleaning standards for your health.' },
    { id: '4', title: 'Flexible Access', icon: 'fa-clock', desc: 'Train at your own convenience with 24/7 unlimited facility access.' },
    { id: '5', title: 'Growth Community', icon: 'fa-users', desc: 'Surround yourself with motivated individuals striving for more.' },
    { id: '6', title: 'No Boundaries', icon: 'fa-infinite', desc: 'No time limits or equipment restrictions. Train how you want.' }
  ],
  pricing: [
    {
      id: 'basic',
      name: 'Basic',
      price: '₹2000',
      period: 'per month',
      features: ['Unlimited 24/7 Access', 'All Equipment Access', 'Standard Locker Room', 'Professional Training Plans', 'No Time Limitations'],
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '₹4800',
      period: 'for 3 months',
      features: ['Unlimited 24/7 Access', 'All Equipment Access', 'Premium Locker Room', 'Professional Training Plans', 'Free Steam & Sauna Access', 'No Time Limitations'],
      recommended: true,
    },
    {
      id: 'elite',
      name: 'Elite',
      price: '₹7500',
      period: 'for 6 months',
      features: ['Unlimited 24/7 Access', 'All Equipment Access', 'VIP Locker Access', 'Professional Training Plans', 'Free Steam & Sauna Access', 'Nutrition & Diet Consulting', 'No Time Limitations'],
    }
  ],
  trainers: [
    {
      id: '1',
      name: 'Alex Rivera',
      specialty: 'Strength & Conditioning',
      image: 'https://picsum.photos/id/64/400/400',
      bio: 'With over 10 years of experience in competitive bodybuilding, Alex focuses on high-intensity muscle building and structural integrity.',
      contact: '+91 98765 43210'
    }
  ],
  reviews: [
    { id: 'r1', name: 'Vikram Singh', rating: 5, comment: 'The best equipment in the city. The atmosphere is purely focused on performance. No distractions.', date: '2024-03-01' },
    { id: 'r2', name: 'Ananya Rao', rating: 5, comment: 'Clean, professional, and the 24/7 access is a life saver for my busy schedule.', date: '2024-03-10' },
    { id: 'r3', name: 'David Miller', rating: 4, comment: 'Great trainers. Alex helped me fix my squat form in just one session. Highly recommend the Pro plan.', date: '2024-03-15' }
  ],
  schedule: [
    { day: 'Monday', hours: '06:00 AM - 10:00 PM', note: 'Standard Training Hours' },
    { day: 'Tuesday', hours: '06:00 AM - 10:00 PM', note: 'Standard Training Hours' },
    { day: 'Wednesday', hours: '06:00 AM - 10:00 PM', note: 'Standard Training Hours' },
    { day: 'Thursday', hours: '06:00 AM - 10:00 PM', note: 'Standard Training Hours' },
    { day: 'Friday', hours: '06:00 AM - 10:00 PM', note: 'Standard Training Hours' },
    { day: 'Saturday', hours: '06:00 AM - 08:00 PM', note: 'Weekend Hours' },
    { day: 'Sunday', hours: '08:00 AM - 06:00 PM', note: 'Active Recovery Day' },
  ],
  athletes: [
    { id: 'ath_1', name: 'John Miller', membershipPlan: 'Elite Performance', joinDate: '2024-01-15', status: 'active' },
    { id: 'ath_2', name: 'Sarah Chen', membershipPlan: 'Pro Strategy', joinDate: '2024-02-10', status: 'active' },
  ],
  attendance: [],
  portalPassword: '1978',
  contact: {
    reception: "+91 12345 67890",
    owner: "+91 54321 09876",
    address: "Good Job Fitness Complex, 123 Green Ave, District Performance Center, New York, NY 10001",
    email: "info@goodjobfitness.com"
  },
  inquiries: [],
  gallery: [
    { id: 'g1', url: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?q=80&w=1200&auto=format&fit=crop' },
    { id: 'g2', url: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=1200&auto=format&fit=crop' }
  ],
  social: {
    facebook: "https://facebook.com/goodjobfitness",
    instagram: "https://instagram.com/goodjobfitness"
  }
};

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<SiteContent>(() => {
    const saved = localStorage.getItem('gj_fitness_content');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...defaultContent, ...parsed, schedule: parsed.schedule || defaultContent.schedule };
      } catch (e) {
        return defaultContent;
      }
    }
    return defaultContent;
  });

  const updateContent = (newContentOrFn: SiteContent | ((prev: SiteContent) => SiteContent)) => {
    setContent(prev => {
      const updated = typeof newContentOrFn === 'function' ? newContentOrFn(prev) : newContentOrFn;
      localStorage.setItem('gj_fitness_content', JSON.stringify(updated));
      return updated;
    });
  };

  const resetToDefault = () => {
    if (window.confirm("This will erase all your custom updates and reset the site to original factory settings. Continue?")) {
      updateContent(defaultContent);
    }
  };

  return (
    <ContentContext.Provider value={{ content, updateContent, resetToDefault }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) throw new Error('useContent must be used within a ContentProvider');
  return context;
};
