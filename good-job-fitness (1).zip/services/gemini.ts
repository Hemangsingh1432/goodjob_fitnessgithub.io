import { GoogleGenAI } from "@google/genai";

// Initialize the GoogleGenAI client at the top level using the environment variable directly.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export class FitnessCoachService {
  async getFitnessAdvice(goal: string, experience: string): Promise<string> {
    try {
      // Use ai.models.generateContent to query the model with task-specific configuration.
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `I am a member at Good Job Fitness Gym. My goal is ${goal} and my experience level is ${experience}. Give me a concise, motivational 3-step plan to start this week.`,
        config: {
          systemInstruction: "You are an expert fitness coach at Good Job Fitness Gym. Be motivational, direct, and professional.",
          temperature: 0.7,
        }
      });
      // The .text property is a getter that returns the extracted string output.
      return response.text || "Keep pushing your limits! Consult our front desk for a specialized plan.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Unable to connect to the coach right now. Keep training hard!";
    }
  }
}

export const fitnessCoach = new FitnessCoachService();